import { NgModule } from '@angular/core';

import { SharedModule } from '../shared/shared.module';
import { SettingsRoutingModule } from './settings.routing';
import { SettingsComponent } from './settings.component';

@NgModule({
  imports: [SharedModule, SettingsRoutingModule],
  providers: [],
  declarations: [SettingsComponent]
})
export class SettingsModule {}
