import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
{ path: '', loadChildren: () => import('./home/home.module').then((m) => m.HomeModule) },
      { path: 'contact', loadChildren: () => import('./contact/contact.module').then((m) => m.ContactModule) },
      { path: 'settings', loadChildren: () => import('./settings/settings.module').then((m) => m.SettingsModule) },
      { path: 'accountinfo', loadChildren: () => import('./pages/accountinfo/accountinfo.module').then((m) => m.AccountinfoModule) },
      { path: 'assetmanagement', loadChildren: () => import('./pages/assetmanagement/assetmanagement.module').then((m) => m.AssetmanagementModule) },
      { path: 'associatedealer1', loadChildren: () => import('./pages/associatedealer1/associatedealer1.module').then((m) => m.Associatedealer1Module) },
      { path: 'associatedealer2', loadChildren: () => import('./pages/associatedealer2/associatedealer2.module').then((m) => m.Associatedealer2Module) },  
      { path: 'customer4', loadChildren: () => import('./pages/customer4/customer4.module').then((m) => m.Customer4Module) },
      { path: 'dealercustomers', loadChildren: () => import('./pages/dealercustomers/dealercustomers.module').then((m) => m.DealercustomersModule) },
      { path: 'groupslist', loadChildren: () => import('./pages/groupslist/groupslist.module').then((m) => m.GroupslistModule) },
  
    ]

  },

  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, useHash: false })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
