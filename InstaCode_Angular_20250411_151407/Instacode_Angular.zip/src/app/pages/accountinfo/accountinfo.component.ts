import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { BreadcrumbModule } from '@michelin/theme';

@Component({
  selector: 'app-accountinfo',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatTabsModule,
    MatSlideToggleModule,
    BreadcrumbModule
  ],
  templateUrl: './accountinfo.component.html',
  styleUrls: ['./accountinfo.component.scss']
})
export class AccountinfoComponent implements OnInit {
  isNationalAccount = new FormControl(false);
  
  accountInfoForm = new FormGroup({
    isNationalAccount: this.isNationalAccount
  });
  
  ngOnInit(): void {
    // Initialize form controls if needed
  }
  
  saveAccountInfo(): void {
    if (this.accountInfoForm.valid) {
      console.log('Form submitted:', this.accountInfoForm.value);
      // Add your save logic here
    }
  }
}