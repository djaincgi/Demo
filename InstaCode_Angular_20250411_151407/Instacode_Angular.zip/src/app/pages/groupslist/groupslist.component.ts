import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

// Michelin Design System Imports
import { BreadcrumbModule } from '@michelin/theme';
import { TableModule, TableConfig, TableComponent } from '@michelin/theme';
import { MaterialModule } from '@michelin/theme';
import { EmptyStateModule } from '@michelin/theme';

interface UserGroup {
  name: string;
  description: string;
  assignedTo: string;
  lastModifiedOn: string;
  lastModifiedBy: string;
}

@Component({
  selector: 'app-groupslist',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    BreadcrumbModule,
    TableModule,
    MaterialModule,
    EmptyStateModule
  ],
  templateUrl: './groupslist.component.html',
  styleUrls: ['./groupslist.component.scss']
})
export class GroupslistComponent implements OnInit {
  @ViewChild(TableComponent) tableRef: TableComponent<UserGroup>;
  
  searchGroupName = new FormControl('');
  searchPermission = new FormControl('');
  
  userGroups: UserGroup[] = [
    { name: 'Initial Inspection', description: 'View/Update Initial Inspection Post', assignedTo: '12 users', lastModifiedOn: '09/09/2022', lastModifiedBy: 'Admin1' },
    { name: 'Buffer', description: 'View/Update Buffer Post', assignedTo: '10 users', lastModifiedOn: '06/23/2023', lastModifiedBy: 'SalesPerson' },
    { name: 'CIA', description: 'View/Update CIA Post', assignedTo: '7 users', lastModifiedOn: '01/15/2020', lastModifiedBy: 'MichIS' },
    { name: 'Skive', description: 'View/Update Skive Post', assignedTo: '5 users', lastModifiedOn: '05/29/2024', lastModifiedBy: 'Admin2' },
    { name: 'Final Inspection', description: 'View/Update Final Inspection Post', assignedTo: '9 users', lastModifiedOn: '01/11/2020', lastModifiedBy: 'MichIS' },
    { name: 'Builder', description: 'View/Update Builder Posts', assignedTo: '16 users', lastModifiedOn: '11/20/2021', lastModifiedBy: 'Admin1' },
    { name: 'Cement/Fill', description: 'View/Update Cement/Fill Post', assignedTo: '8 users', lastModifiedOn: '12/05/2020', lastModifiedBy: 'SalesPerson' },
    { name: 'Repair', description: 'View/Update Repair Post', assignedTo: '4 users', lastModifiedOn: '06/18/2020', lastModifiedBy: 'Admin1' },
    { name: 'Tread Preparation', description: 'View/Update Tread Preparation Post', assignedTo: '8 users', lastModifiedOn: '01/11/2024', lastModifiedBy: 'MichIS' }
  ];
  
  dataSource = new MatTableDataSource<UserGroup>(this.userGroups);
  
  tableConfig: TableConfig<UserGroup> = {
    selection: {
      columnKeyForCheckboxLabel: 'name'
    },
    columns: {
      name: { 
        cell: (item: UserGroup) => item.name, 
        header: 'User Group Name'
      },
      description: { 
        cell: (item: UserGroup) => item.description, 
        header: 'Description'
      },
      assignedTo: { 
        cell: (item: UserGroup) => item.assignedTo, 
        header: 'Assigned to',
        sortable: true
      },
      lastModifiedOn: { 
        cell: (item: UserGroup) => item.lastModifiedOn, 
        header: 'Last modified on',
        sortable: true
      },
      lastModifiedBy: { 
        cell: (item: UserGroup) => item.lastModifiedBy, 
        header: 'Last modified by',
        sortable: true
      }
    },
    rows: {
      menu: {
        disabled: () => false
      }
    },
    onSelectionChange: (selectedItems: UserGroup[]) => {
      console.log('Selected items:', selectedItems);
    }
  };

  ngOnInit() {
    this.searchGroupName.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(value => {
        this.filterTable();
      });
    
    this.searchPermission.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(value => {
        this.filterTable();
      });
  }

  filterTable() {
    const groupNameValue = this.searchGroupName.value?.toLowerCase() || '';
    const permissionValue = this.searchPermission.value?.toLowerCase() || '';
    
    this.dataSource.filter = JSON.stringify({
      groupName: groupNameValue,
      permission: permissionValue
    });
    
    this.dataSource.filterPredicate = (data, filter) => {
      const filterValues = JSON.parse(filter);
      const nameMatch = data.name.toLowerCase().includes(filterValues.groupName);
      const descMatch = data.description.toLowerCase().includes(filterValues.permission);
      
      return nameMatch && descMatch;
    };
  }

  deleteSelected() {
    console.log('Delete selected groups');
  }
  
  addUserGroup() {
    console.log('Add user group');
  }
}