import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { GroupslistRoutingModule } from './groupslist.routing';
                    import { GroupslistComponent } from './groupslist.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        GroupslistRoutingModule,
                        GroupslistComponent
                    ],
                    providers: [],
                    })
                    export class GroupslistModule {}
                    