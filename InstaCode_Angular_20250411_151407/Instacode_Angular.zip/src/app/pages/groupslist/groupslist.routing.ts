import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { GroupslistComponent } from './groupslist.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: GroupslistComponent
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class GroupslistRoutingModule { }
                    