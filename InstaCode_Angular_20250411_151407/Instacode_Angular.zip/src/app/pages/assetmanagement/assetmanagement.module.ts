import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { AssetmanagementRoutingModule } from './assetmanagement.routing';
                    import { AssetmanagementComponent } from './assetmanagement.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        AssetmanagementRoutingModule,
                        AssetmanagementComponent
                    ],
                    providers: [],
                    })
                    export class AssetmanagementModule {}
                    