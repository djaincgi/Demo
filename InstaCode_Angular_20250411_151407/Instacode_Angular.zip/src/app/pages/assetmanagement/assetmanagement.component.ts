import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BreadcrumbModule } from '@michelin/theme';
import { IconModule } from '@michelin/theme';
import { MainContentModule } from '@michelin/theme';

@Component({
  selector: 'app-assetmanagement',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatRadioModule,
    MatTabsModule,
    MatFormFieldModule,
    BreadcrumbModule,
    IconModule,
    MainContentModule
  ],
  templateUrl: './assetmanagement.component.html',
  styleUrls: ['./assetmanagement.component.scss']
})
export class AssetmanagementComponent implements OnInit {
  camSpecForm: FormGroup;
  
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.camSpecForm = this.fb.group({
      camSpecName: [''],
      repairLimit: ['lifetime']
    });
  }

  viewCamSpec() {
    console.log('View CAM Spec clicked');
  }

  exportCamSpec() {
    console.log('Export CAM Spec clicked');
  }
}