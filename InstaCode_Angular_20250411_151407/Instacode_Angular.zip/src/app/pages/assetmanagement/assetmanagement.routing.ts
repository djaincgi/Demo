import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { AssetmanagementComponent } from './assetmanagement.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: AssetmanagementComponent
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class AssetmanagementRoutingModule { }
                    