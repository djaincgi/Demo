import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { Associatedealer2RoutingModule } from './associatedealer2.routing';
                    import { Associatedealer2Component } from './associatedealer2.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        Associatedealer2RoutingModule,
                        Associatedealer2Component
                    ],
                    providers: [],
                    })
                    export class Associatedealer2Module {}
                    