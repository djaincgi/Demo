import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { Associatedealer2Component } from './associatedealer2.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: Associatedealer2Component
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class Associatedealer2RoutingModule { }
                    