import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { TableConfig } from '@michelin/theme';

// Material imports
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';

// Michelin imports
import { BreadcrumbModule } from '@michelin/theme';
import { TableModule } from '@michelin/theme';
import { PaginatorModule } from '@michelin/theme';

interface CustomerData {
  customerCode: string;
  customerName: string;
  city: string;
  type: string;
  camSpecName: string;
  btmFlag: string;
  state: string;
  status: string;
}

@Component({
  selector: 'app-associatedealer2',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSelectModule,
    MatCheckboxModule,
    BreadcrumbModule,
    TableModule,
    PaginatorModule
  ],
  templateUrl: './associatedealer2.component.html',
  styleUrls: ['./associatedealer2.component.scss']
})
export class Associatedealer2Component implements OnInit {
  searchControl = new FormControl('');
  pageSizeControl = new FormControl('9');
  
  dataSource = new MatTableDataSource<CustomerData>([
    { customerCode: '5640409', customerName: 'TCI CENTERED ON YOU', city: 'HARAHAN', type: 'Associate Dealer', camSpecName: '124578', btmFlag: 'Yes', state: 'LA', status: 'Active' },
    { customerCode: '200632', customerName: '***** FEDEX NATIONAL LTL', city: 'NAZARETH', type: 'Michelin Customer', camSpecName: '135705', btmFlag: 'Yes', state: 'PA', status: 'Active' },
    { customerCode: '187882', customerName: '***** FEDEX NATIONAL LTL', city: 'CHESTER SPRINGS', type: 'Michelin Customer', camSpecName: '2580361', btmFlag: 'Yes', state: 'PA', status: 'Active' },
    { customerCode: '187888', customerName: '***** FEDEX NATIONAL LTL', city: 'MANASSAS', type: 'Associate Dealer', camSpecName: '', btmFlag: '', state: 'PA', status: 'Active' },
    { customerCode: '9028', customerName: '***** FEDEX NATIONAL LTL', city: 'MIDDLETON', type: 'Associate Dealer', camSpecName: '', btmFlag: '', state: 'PA', status: 'Active' },
    { customerCode: '89030', customerName: '***** FEDEX NATIONAL LTL', city: 'CROYDEN', type: 'Customer', camSpecName: '', btmFlag: '', state: 'PA', status: 'Active' },
    { customerCode: '89035', customerName: '***** FEDEX NATIONAL LTL', city: 'LAKELAND', type: 'Associate Dealer Customer', camSpecName: '', btmFlag: '', state: 'FL', status: 'Active' },
    { customerCode: '888984', customerName: '***** FEDEX NATIONAL LTL', city: 'LAKELAND', type: 'Associate Dealer Customer', camSpecName: '', btmFlag: '', state: 'FL', status: 'Active' },
    { customerCode: '89019', customerName: '***** FEDEX NATIONAL LTL', city: 'WILKES BARRE', type: 'Customer', camSpecName: '', btmFlag: '', state: 'PA', status: 'Active' }
  ]);

  tableConfig: TableConfig<CustomerData> = {
    onSelectionChange: (items: CustomerData[]) => console.log('Selection changed', items),
    columns: {
      customerCode: { cell: 'customerCodeCell', header: 'Customer Code' },
      customerName: { cell: 'customerNameCell', header: 'Customer Name' },
      city: { cell: 'cityCell', header: 'City' },
      type: { cell: 'typeCell', header: 'typeHeader', sortable: true },
      camSpecName: { cell: 'camSpecNameCell', header: 'CAM Spec Name' },
      btmFlag: { cell: 'btmFlagCell', header: 'BTM Flag' },
      state: { cell: 'stateCell', header: 'stateHeader', sortable: true },
      status: { cell: 'statusCell', header: 'statusHeader', sortable: true }
    }
  };

  ngOnInit(): void {
    this.searchControl.valueChanges.subscribe(value => {
      this.dataSource.filter = value?.trim().toLowerCase() || '';
    });
  }
}