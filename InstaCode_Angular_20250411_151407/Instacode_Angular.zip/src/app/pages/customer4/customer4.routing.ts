import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { Customer4Component } from './customer4.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: Customer4Component
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class Customer4RoutingModule { }
                    