import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { CommonModule } from '@angular/common';
import { BreadcrumbModule } from '@michelin/theme';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-customer4',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatIconModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatExpansionModule,
    BreadcrumbModule,
    MatTabsModule
  ],
  templateUrl: './customer4.component.html',
  styleUrls: ['./customer4.component.scss']
})
export class Customer4Component implements OnInit {
  customerForm: FormGroup;
  
  constructor(private fb: FormBuilder) {}
  
  ngOnInit() {
    this.customerForm = this.fb.group({
      isNationalAccount: [false],
      fleet: [''],
      fleetName: [''],
      address: [''],
      city: [''],
      state: [''],
      shipToNumber: [''],
      billToNumber: [''],
      dbaName: [''],
      homeOfficeNumber: [''],
      fleetHomeOfficeName: [''],
      parentCompanyNumber: [''],
      parentCompanyName: [''],
      category: ['']
    });
  }
  
  saveCustomer() {
    if (this.customerForm.valid) {
      console.log('Customer data saved:', this.customerForm.value);
    }
  }
}