import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { Customer4RoutingModule } from './customer4.routing';
                    import { Customer4Component } from './customer4.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        Customer4RoutingModule,
                        Customer4Component
                    ],
                    providers: [],
                    })
                    export class Customer4Module {}
                    