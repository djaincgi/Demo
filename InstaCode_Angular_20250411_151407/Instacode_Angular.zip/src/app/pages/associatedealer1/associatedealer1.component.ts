import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { TableConfig, TableModule } from '@michelin/theme';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { MatPaginatorModule } from '@angular/material/paginator';
import { BreadcrumbModule } from '@michelin/theme';
import { MatTableDataSource } from '@angular/material/table';
interface CustomerData {
  customerCode: string;
  customerName: string;
  city: string;
  state: string;
  shipToCode: string;
  status: string;
  isActive: boolean;
}

@Component({
  selector: 'app-associatedealer1',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    TableModule,
    MatDividerModule,
    MatCardModule,
    MatPaginatorModule,
    BreadcrumbModule
  ],
  templateUrl: './associatedealer1.component.html',
  styleUrls: ['./associatedealer1.component.scss']
})
export class Associatedealer1Component implements OnInit {
  pageSize = 9;
  currentPage = 0;
  totalItems = 10;

  tableConfig: TableConfig<CustomerData> = {
    columns: {
      customerCode: { 
        header: 'Customer Code',
        cell: (item: CustomerData) => item.customerCode 
      },
      customerName: { 
        header: 'Customer Name',
        cell: (item: CustomerData) => item.customerName 
      },
      city: { 
        header: 'City',
        cell: (item: CustomerData) => item.city 
      },
      state: { 
        header: 'State/province',
        cell: (item: CustomerData) => item.state 
      },
      shipToCode: { 
        header: 'Ship-to-code',
        cell: (item: CustomerData) => item.shipToCode,
        sortable: true
      },
      status: { 
        header: 'Status',
        cell: 'statusCell',
        sortable: true
      }
    }
  };

  dataSource= new MatTableDataSource<CustomerData>([
    {
      customerCode: 'ALS 2',
      customerName: 'ALS TRUCKING',
      city: 'ANNAPOLIS JUNCTION',
      state: 'MD',
      shipToCode: '',
      status: 'Active',
      isActive: true
    },
    {
      customerCode: '123',
      customerName: 'JH TEST ADC',
      city: 'GREENVILLE',
      state: 'SC',
      shipToCode: '',
      status: 'Inactive',
      isActive: false
    }
  ]);

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {}
}