import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { Associatedealer1RoutingModule } from './associatedealer1.routing';
                    import { Associatedealer1Component } from './associatedealer1.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        Associatedealer1RoutingModule,
                        Associatedealer1Component
                    ],
                    providers: [],
                    })
                    export class Associatedealer1Module {}
                    