import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { Associatedealer1Component } from './associatedealer1.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: Associatedealer1Component
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class Associatedealer1RoutingModule { }
                    