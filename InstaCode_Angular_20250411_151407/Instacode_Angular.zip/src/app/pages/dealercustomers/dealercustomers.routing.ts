import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { DealercustomersComponent } from './dealercustomers.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: DealercustomersComponent
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class DealercustomersRoutingModule { }
                    