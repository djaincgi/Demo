import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatSortModule, Sort } from '@angular/material/sort';
import { MatTabsModule } from '@angular/material/tabs';
import { MatPaginatorModule } from '@angular/material/paginator';
import { BreadcrumbModule } from '@michelin/theme';
import { EmptyStateModule } from '@michelin/theme';
import { TableModule,TableConfig } from '@michelin/theme';

interface CustomerData {
  customerCode: string;
  customerName: string;
  city: string;
  stateProvince: string;
  shipToCode: string;
  status: string;
}

@Component({
  selector: 'app-dealercustomers',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatSortModule,
    MatTabsModule,
    MatPaginatorModule,
    BreadcrumbModule,
    EmptyStateModule,
    TableModule
  ],
  templateUrl: './dealercustomers.component.html',
  styleUrls: ['./dealercustomers.component.scss']
})
export class DealercustomersComponent implements OnInit {
  // Customer details
  customerCode = '5640409';
  customerName = 'TCI CENTERED ON YOU';
  
  // Table configuration
  dataSource = new MatTableDataSource<CustomerData>([]);
  
  tableConfig: TableConfig<CustomerData> = {
    columns: {
      customerCode: { cell: (item) => item.customerCode, header: 'Customer Code' },
      customerName: { cell: (item) => item.customerName, header: 'Customer Name' },
      city: { cell: (item) => item.city, header: 'City' },
      stateProvince: { cell: (item) => item.stateProvince, header: 'State/province' },
      shipToCode: { cell: (item) => item.shipToCode, header: 'Ship-to-code', sortable: true },
      status: { cell: (item) => item.status, header: 'Status', sortable: true }
    },
  };

  constructor() {}

  ngOnInit(): void {
    // Initialize with empty data
  }

  saveCustomer(): void {
    // Save customer implementation
  }
}