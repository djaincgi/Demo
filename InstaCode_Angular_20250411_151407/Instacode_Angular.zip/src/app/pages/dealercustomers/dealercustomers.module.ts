import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { DealercustomersRoutingModule } from './dealercustomers.routing';
                    import { DealercustomersComponent } from './dealercustomers.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        DealercustomersRoutingModule,
                        DealercustomersComponent
                    ],
                    providers: [],
                    })
                    export class DealercustomersModule {}
                    