import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDividerModule } from '@angular/material/divider';
import { BreadcrumbModule } from '@michelin/theme';
import { FlexLayoutModule } from '@angular/flex-layout';

@Component({
  selector: 'app-assetmanagement',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    MatDividerModule,
    BreadcrumbModule,
    FlexLayoutModule
  ],
  templateUrl: './assetmanagement.component.html',
  styleUrls: ['./assetmanagement.component.scss']
})
export class AssetmanagementComponent implements OnInit {
  assetForm: FormGroup;
  
  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.assetForm = this.fb.group({
      camSpecName: [''],
      repairLimit: ['lifetime']
    });
  }

  viewCamSpec(): void {
    console.log('View CAM Spec clicked');
  }

  exportCamSpec(): void {
    console.log('Export CAM Spec clicked');
  }
}