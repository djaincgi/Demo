import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { BreadcrumbModule } from '@michelin/theme';

@Component({
  selector: 'app-pos',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatExpansionModule,
    BreadcrumbModule
  ],
  templateUrl: './pos.component.html',
  styleUrls: ['./pos.component.scss']
})
export class PosComponent implements OnInit {
  posForm: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm(): void {
    this.posForm = this.fb.group({
      // Export Setup
      activateBtDownload: [false],
      exportToFile: [true],
      exportDirectory: [''],
      archiveDirectory: [''],
      frequency: [''],

      // Import Setup
      importFromFile: [true],
      customers: [false],
      inventory: [false],
      invoicingResults: [false],
      importDirectory: [''],
      archiveDirectoryImport: [''],
      frequencyImport: [''],

      // Point of Sale Interface
      name: [''],
      enablePosInterface: [true],
      acceptInvoiceResults: [false],
      includeCrnShipping: [false],
      roProduct: [''],
      ioProduct: [''],
      soProduct: [''],
      archiveDirectoryPos: [''],
      parts: [''],
      adjustmentResearch: [''],
      adjustmentScrap: [''],
      npProduct: ['']
    });
  }

  onSubmit(): void {
    if (this.posForm.valid) {
      console.log('Form submitted:', this.posForm.value);
    }
  }
}