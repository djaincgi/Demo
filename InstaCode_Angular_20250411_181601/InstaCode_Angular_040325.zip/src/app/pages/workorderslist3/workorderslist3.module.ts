import { NgModule } from '@angular/core';
                    import { SharedModule } from '../../shared/shared.module';
                    import { Workorderslist3RoutingModule } from './workorderslist3.routing';
                    import { Workorderslist3Component } from './workorderslist3.component';

                    @NgModule({
                    imports: [
                        SharedModule,
                        Workorderslist3RoutingModule,
                        Workorderslist3Component
                    ],
                    providers: [],
                    })
                    export class Workorderslist3Module {}
                    