import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { MatTableDataSource } from '@angular/material/table';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BreadcrumbModule, TableModule, EmptyStateModule } from '@michelin/theme';
import { TableConfig } from '@michelin/theme';

interface WorkOrder {
  customerCode: string;
  customerName: string;
  plant: string;
  site: string;
  workOrderNumber: string;
  workOrderStatus: string;
  numberOfLines: number;
  salesId: string;
  received: string;
  due: string;
}

@Component({
  selector: 'app-workorderslist3',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatMenuModule,
    MatSelectModule,
    FlexLayoutModule,
    BreadcrumbModule,
    TableModule,
    EmptyStateModule
  ],
  templateUrl: './workorderslist3.component.html',
  styleUrls: ['./workorderslist3.component.scss']
})
export class Workorderslist3Component implements OnInit {
  dataSource = new MatTableDataSource<WorkOrder>([]);
  
  tableConfig: TableConfig<WorkOrder> = {
    columns: {
      customerCode: { 
        cell: 'customerCodeCell', 
        header: 'customerCodeHeader',
        sortable: true
      },
      customerName: { 
        cell: 'customerNameCell', 
        header: 'customerNameHeader',
        sortable: true
      },
      plant: { 
        cell: 'plantCell', 
        header: 'plantHeader',
        sortable: true
      },
      site: { 
        cell: 'siteCell', 
        header: 'siteHeader',
        sortable: true
      },
      workOrderNumber: { 
        cell: 'workOrderNumberCell', 
        header: 'workOrderNumberHeader',
        sortable: true
      },
      workOrderStatus: { 
        cell: 'workOrderStatusCell', 
        header: 'workOrderStatusHeader',
        sortable: true
      },
      numberOfLines: { 
        cell: 'numberOfLinesCell', 
        header: 'numberOfLinesHeader',
        sortable: true
      },
      salesId: { 
        cell: 'salesIdCell', 
        header: 'salesIdHeader',
        sortable: true
      },
      received: { 
        cell: 'receivedCell', 
        header: 'receivedHeader',
        sortable: true
      },
      due: { 
        cell: 'dueCell', 
        header: 'dueHeader',
        sortable: true
      },
      actions: { 
        cell: 'actionsCell', 
        header: 'actionsHeader'
      }
    }
  };

  ngOnInit(): void {
    this.loadWorkOrdersData();
  }

  loadWorkOrdersData(): void {
    const workOrders: WorkOrder[] = [
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1311175',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'RELEASED',
        numberOfLines: 9,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1406396',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'COMPLETED',
        numberOfLines: 4,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1517193',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'COMPLETED',
        numberOfLines: 2,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '0347286',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'CLOSED',
        numberOfLines: 17,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1378812',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'RELEASED',
        numberOfLines: 40,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '0322539',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'RELEASED',
        numberOfLines: 34,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1406388',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'CLOSED',
        numberOfLines: 16,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1325350',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'CLOSED',
        numberOfLines: 5,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      },
      {
        customerCode: 'OLD024',
        customerName: 'DOMINION FREIGHT',
        plant: '1496830',
        site: '62 - 62-PVILLE RBC',
        workOrderNumber: 'SV99999999',
        workOrderStatus: 'CLOSED',
        numberOfLines: 8,
        salesId: 'MichIS',
        received: '2023/11/01',
        due: '2023/11/01'
      }
    ];

    this.dataSource = new MatTableDataSource<WorkOrder>(workOrders);
  }

  clearSelection(): void {
    // Logic to clear selection
  }

  createWorkOrder(): void {
    // Logic to create work order
  }
}