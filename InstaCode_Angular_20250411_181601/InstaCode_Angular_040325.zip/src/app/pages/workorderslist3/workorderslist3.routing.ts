import { NgModule } from '@angular/core';
                    import { RouterModule, Routes } from '@angular/router';
                    import { Workorderslist3Component } from './workorderslist3.component';

                    const routes: Routes = [
                    {
                        path: '',
                        component: Workorderslist3Component
                    }
                    ];

                    @NgModule({
                    imports: [RouterModule.forChild(routes)],
                    exports: [RouterModule]
                    })
                    export class Workorderslist3RoutingModule { }
                    