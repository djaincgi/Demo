import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { BreadcrumbModule } from '@michelin/theme';
import { FlexLayoutModule } from '@angular/flex-layout';

@Component({
  selector: 'app-customersettings',
  standalone: true,
  imports: [MatButtonModule,MatFormFieldModule,MatInputModule,MatSelectModule,MatCheckboxModule,MatSlideToggleModule,MatExpansionModule,MatDividerModule,BreadcrumbModule,FlexLayoutModule],
  templateUrl: './customersettings.component.html',
  styleUrls: ['./customersettings.component.scss']
})
export class CustomersettingsComponent implements OnInit {
  customerSettingsForm: FormGroup;
  
  constructor(
    private fb: FormBuilder,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm(): void {
    this.customerSettingsForm = this.fb.group({
      casingCredit: [''],
      casingPurchase: [''],
      michelinShipTo: [''],
      michelinBillTo: [''],
      preferredTreads: [''],
      casingGrade: [''],
      freeRepairs: [''],
      turnaroundTime: ['', Validators.required],
      brandNumber: ['', Validators.required],
      rememberBrand: ['', Validators.required],
      rememberCasingNote: ['', Validators.required],
      rtDot: [''],
      language: [''],
      wheelProcessing: [true],
      remainingTreadDepth: [''],
      customerRejects: ['', Validators.required],
      stocksRejects: ['', Validators.required],
      scrapDisposalCharge: ['', Validators.required],
      scrapCasingAtPlant: [false, Validators.required],
      centralReject: [false],
      includeScrapCasings: [false],
      finishedLabel: ['', Validators.required],
      rejectReturnLabel: ['', Validators.required],
      rejectScrapLabel: ['', Validators.required],
      interfaceId1: [{value: '', disabled: true}],
      interfaceId2: [{value: '', disabled: true}],
      notes: ['']
    });
  }

  saveCustomerSettings(): void {
    if (this.customerSettingsForm.valid) {
      // Save customer settings
      this.snackBar.open('Customer settings saved successfully', 'Close', {
        duration: 3000
      });
    } else {
      this.snackBar.open('Please fill all required fields', 'Close', {
        duration: 3000
      });
    }
  }
}